# CSCI 3170: Recruitment System Project

## Group Information
Random8  
1155128805 - KIM Jia Aileen  
1155079784 - SIU King Hang  
1155064425 - YEUNG Yan Yin Andrew


## Compiling
### Using Terminal

Download "out.jar" from /java/out.jar
Open the command prompt/terminal. Navigate to the folder containing the downloaded "out.jar" file.
Type "java -jar out.jar" to run the program.

### Using Eclipse
Using Eclipse to open project folder
(i.e. /java)

Compile it using eclipse.
If "Driver is not found." is prompted, install the mysql-connector
(i.e. /java/lib)
or follow http://www.ccs.neu.edu/home/kathleen/classes/cs3200/JDBCtutorial.pdf

## Execution
Put test_data folder at the same path of the executable for data loading
(test-daata: /java/test_data)
